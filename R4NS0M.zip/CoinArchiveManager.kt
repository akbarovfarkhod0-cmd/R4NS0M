package com.fl0pp3r.r4ns0m

import android.content.Context

class CoinArchiveManager(private val context: Context) {

    companion object {
        // Базовое количество монет в архиве для инициализации сессии
        const val COIN_COUNT = 0
    }

    /**
     * Очистка или "шифрование" игровых монет при проигрыше Ransom
     */
    suspend fun cleanupCoins() {
        val prefs = context.getSharedPreferences("game_settings", Context.MODE_PRIVATE)
        prefs.edit().putInt("saved_coins", 0).apply()
    }
}
