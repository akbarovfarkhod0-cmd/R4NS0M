package com.fl0pp3r.r4ns0mimport android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("game_settings", Context.MODE_PRIVATE)
        val isFirstLaunch = prefs.getBoolean("is_first_launch", true)
        val isA90Enabled = prefs.getBoolean("a90_enabled", true)

        // 1. Проверка разрешения на оверлеи
        if (!checkOverlayPermission()) {
            requestOverlayPermission()
            return
        }

        // 2. Безопасный шлюз от замкнутого цикла вылетов
        if (!isA90Enabled) {
            initSettingsScreen(prefs)
            return
        }

        // 3. Обработка первого и последующих запусков
        if (isFirstLaunch) {
            prefs.edit().putBoolean("is_first_launch", false).apply()
            startBackgroundGameService()
            finish() 
        } else {
            initSettingsScreen(prefs)
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true 
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Toast.makeText(
                this, 
                "Разрешите отображение поверх других окон для работы Ransom (A-90)!", 
                Toast.LENGTH_LONG
            ).show()
            
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            finish() 
        }
    }

    private fun initSettingsScreen(prefs: android.content.SharedPreferences) {
        setContentView(R.layout.activity_main)

        val switchA90 = findViewById<Switch>(R.id.switch_a90)
        val radioGroupMode = findViewById<RadioGroup>(R.id.radio_group_mode)
        val btnSave = findViewById<Button>(R.id.btn_save)

        switchA90.isChecked = prefs.getBoolean("a90_enabled", true)
        
        val isScreenMode = prefs.getBoolean("collect_on_screen", false)
        radioGroupMode.check(if (isScreenMode) R.id.radio_screen else R.id.radio_gallery)

        btnSave.setOnClickListener {
            val selectedModeId = radioGroupMode.checkedRadioButtonId
            val collectOnScreen = (selectedModeId == R.id.radio_screen)

            prefs.edit().apply {
                putBoolean("a90_enabled", switchA90.isChecked)
                putBoolean("collect_on_screen", collectOnScreen)
                apply()
            }

            val serviceIntent = Intent(this, GameBackgroundService::class.java).apply {
                putExtra("update_settings", true)
            }
            startService(serviceIntent)
            
            Toast.makeText(this, "Настройки успешно применены!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun startBackgroundGameService() {
        val intent = Intent(this, GameBackgroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
