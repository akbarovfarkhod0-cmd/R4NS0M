package com.fl0pp3r.r4ns0m

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlin.random.Random

class GameBackgroundService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayRoot: FrameLayout? = null
    private lateinit var layoutParams: WindowManager.LayoutParams

    private val handler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var coinManager: CoinArchiveManager

    private var mediaPlayer: MediaPlayer? = null
    private var themePlayer: MediaPlayer? = null 

    private var characterView  : ImageView?   = null  
    private var panicView      : ImageView?   = null  
    private var loadingOverlay : FrameLayout? = null  
    private var ransomWidget   : FrameLayout? = null  
    private var widgetTimerText: TextView?    = null
    private var widgetScoreText: TextView?    = null
    private var blackScreenView: View?        = null  
    private var progressContainer : FrameLayout? = null // Контейнер загрузки
    private var progressBarBg     : View?        = null // Белый фон шкалы
    private var progressBarFill   : View?        = null // Зелёное заполнение шкалы
    private var downloadText      : TextView?    = null // Текст "DOWNLOADING"

    private var isPanicMode  = false
    private var strobeToggle = false
    private var strobeCount  = 0

    private var gameScore     = 500
    private var lastCoinCount = CoinArchiveManager.COIN_COUNT
    private var gameActive    = false

    private var isA90Enabled = true
    private var collectModeOnScreen = false

    private var countdownJob   : Job? = null
    private var coinMonitorJob : Job? = null
    private var teleportJob    : Job? = null

    companion object {
        private const val CHANNEL_ID      = "overlay_game_channel"
        private const val NOTIFICATION_ID = 1

        private const val CHARACTER_SPAWN_INTERVAL = 30_000L
        private const val CHARACTER_HIDE_DELAY     =  2_000L
        private const val PANIC_TOTAL_DURATION     =  1_000L
        private const val STROBE_FRAME_INTERVAL    =    150L

        private val TOTAL_STROBE_FRAMES = (PANIC_TOTAL_DURATION / STROBE_FRAME_INTERVAL).toInt()

        private const val NORMAL_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

        private const val PANIC_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        val GAME_IMAGE_ASSETS = intArrayOf(
            R.drawable.image1, R.drawable.image2, R.drawable.image3,
            R.drawable.image4, R.drawable.image5, R.drawable.image6
        )
    }

    private val spawnRunnable = object : Runnable {
        override fun run() {
            if (isA90Enabled && !isPanicMode && !gameActive) {
                spawnCharacter()
            }
            handler.postDelayed(this, CHARACTER_SPAWN_INTERVAL)
        }
    }

    private val hideCharacterRunnable = Runnable {
        characterView?.visibility = View.INVISIBLE
    }

    private val strobeRunnable = object : Runnable {
        override fun run() {
            if (strobeCount >= TOTAL_STROBE_FRAMES) {
                endPanicMode()
                return
            }
            panicView?.setImageResource(
                if (strobeToggle) R.drawable.ransom_face_a else R.drawable.ransom_face_b
            )
            strobeToggle = !strobeToggle
            strobeCount++
            handler.postDelayed(this, STROBE_FRAME_INTERVAL)
        }
    }

    override fun onCreate() {
        super.onCreate()
        coinManager = CoinArchiveManager(this)
        loadPersistentSettings()
        startForegroundWithNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
        serviceScope.launch { cleanupPreviousSession() }
        handler.postDelayed(spawnRunnable, CHARACTER_SPAWN_INTERVAL)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let { if (it.hasExtra("update_settings")) loadPersistentSettings() }
        return START_STICKY
    }

    private fun loadPersistentSettings() {
        val prefs = getSharedPreferences("game_settings", Context.MODE_PRIVATE)
        isA90Enabled = prefs.getBoolean("a90_enabled", true)
        collectModeOnScreen = prefs.getBoolean("collect_on_screen", false)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        cancelGameJobs()
        releaseAudio()
        stopThemeTrack()
        serviceScope.launch { coinManager.cleanupCoins() }
        serviceScope.cancel()
        overlayRoot?.let { runCatching { windowManager.removeView(it) } }
        overlayRoot = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Overlay Game", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Игра-виджет активна")
            .setContentText("Наблюдай за экраном...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

private fun createOverlay() {
    layoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        NORMAL_FLAGS, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    overlayRoot = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }

    // =========================================================================
    // 1. СЛОЙ КРАСНЫХ ПОМЕХ И АНИМИРОВАННОЙ ЗАГРУЗКИ (Вместо черного экрана)
    // =========================================================================
    progressContainer = FrameLayout(this).apply {
        setBackgroundColor(Color.parseColor("#33FF0000")) // Полупрозрачные красные помехи на весь экран
        visibility = View.GONE
        setOnTouchListener { _, _ -> true } // Полная блокировка слепых кликов

        // Центрированный контейнер для текста и шкалы
        val centerBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        }

        // Текст "DOWNLOADING"
        downloadText = TextView(context).apply {
            text = "DOWNLOADING"
            textColor = Color.WHITE
            textSize = 22f
            textStyle = android.graphics.Typeface.MONOSPACE or android.graphics.Typeface.BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 30)
        }

        // Сама шкала (Контейнер: Белая подложка)
        progressBarBg = FrameLayout(context).apply {
            setBackgroundColor(Color.WHITE) // Белая шкала
            layoutParams = LinearLayout.LayoutParams(600, 40).apply {
                gravity = Gravity.CENTER
            }

            // Заполнение шкалы (Зеленая полоса внутри)
            progressBarFill = View(context).apply {
                setBackgroundColor(Color.GREEN) // Изначально зеленая
                layoutParams = FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT)
            }
            addView(progressBarFill)
        }

        centerBox.addView(downloadText)
        centerBox.addView(progressBarBg)
        addView(centerBox)
    }

     // =========================================================================
    // 2. СЛОЙ ОКНА ВЫКУПА RANSOM WIDGET (Обновленный)
    // =========================================================================
    ransomWidget = FrameLayout(this).apply {
        setBackgroundColor(Color.parseColor("#AA000000")) // Затемнение экрана под виджетом
        visibility = View.GONE
        setOnTouchListener { _, _ -> true } // Блокировка кликов мимо кнопок игры

        val contentLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1F0000")) // Кроваво-красный бэкграунд хакера
            setPadding(60, 60, 60, 60)
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        }

        // Стартовое значение текстового таймера (1 минута 30 секунд)
        widgetTimerText = TextView(context).apply {
            text = "01:30" 
            textColor = Color.RED
            textSize = 28f
            textStyle = android.graphics.Typeface.MONOSPACE or android.graphics.Typeface.BOLD
            setPadding(0, 0, 0, 20)
        }

        val alertText = TextView(context).apply {
            text = "SYSTEM ENCRYPTED BY RANSOM.EXE\nPAYMENT REQUIRED: 500 COINS"
            textColor = Color.WHITE
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
        }

        val payButton = Button(context).apply {
            text = "PAY RANSOM"
            backgroundTintList = android.content.res.ColorStateList.valueOf(Color.RED)
            textColor = Color.WHITE
            setOnClickListener { onRansomSuccessPaid() }
        }

        contentLayout.addView(widgetTimerText)
        contentLayout.addView(alertText)
        contentLayout.addView(payButton)
        addView(contentLayout)
    }
	

    // =========================================================================
    // 3. БАЗОВЫЕ СЛОИ СУЩНОСТИ (Стробоскоп и Персонаж)
    // =========================================================================
    panicView = ImageView(this).apply {
        setImageResource(R.drawable.ransom_face_a)
        scaleType = ImageView.ScaleType.FIT_XY
        visibility = View.INVISIBLE
    }

    characterView = ImageView(this).apply {
        setImageResource(R.drawable.image1)
        visibility = View.INVISIBLE
        layoutParams = FrameLayout.LayoutParams(200, 200)
        setOnClickListener {
            if (collectModeOnScreen) {
                gameScore += 50
                visibility = View.INVISIBLE
                handler.removeCallbacks(hideCharacterRunnable)
            }
        }
    }

    // Сборка слоев в правильном порядке наложения (сверху вниз)
    overlayRoot!!.apply {
        addView(ransomWidget)       // Самый нижний игровой слой
        addView(progressContainer)  // Слой загрузки (перекрывает виджет во время Fade Out)
        addView(panicView)          // Слой скримера
        addView(characterView)      // Персонаж на самом верху
    }
    windowManager.addView(overlayRoot, layoutParams)
}


    private fun spawnCharacter() {
        if (!isA90Enabled) return
        isPanicMode = true
        strobeCount = 0

        executeAudioTrack(R.raw.ransom_exe_warning)

        val width = windowManager.defaultDisplay.width - 200
        val height = windowManager.defaultDisplay.height - 200
        characterView?.translationX = Random.nextInt(0, maxOf(1, width)).toFloat()
        characterView?.translationY = Random.nextInt(0, maxOf(1, height)).toFloat()

        panicView?.visibility = View.VISIBLE
        characterView?.visibility = View.VISIBLE

        handler.post(strobeRunnable)
        handler.postDelayed(hideCharacterRunnable, CHARACTER_HIDE_DELAY)

        layoutParams.flags = PANIC_FLAGS
        runCatching { windowManager.updateViewLayout(overlayRoot, layoutParams) }

        overlayRoot?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                onPlayerFailedA90()
            }
            true
        }
    }

    private fun onPlayerFailedA90() {
    handler.removeCallbacks(strobeRunnable)
    handler.removeCallbacks(hideCharacterRunnable)
    characterView?.visibility = View.INVISIBLE
    panicView?.visibility = View.INVISIBLE

    // Воспроизводим звук скримера-атаки (doors-archives-sfx_-ransom-attack.mp3)
    executeAudioTrack(R.raw.doors_archives_sfx_ransom_attack)

    // Включаем слой красных помех и загрузки
    progressContainer?.visibility = View.VISIBLE
    progressContainer?.alpha = 1.0f

    // Сброс шкалы в 0
    val bgParams = progressBarBg?.layoutParams as? LinearLayout.LayoutParams
    val maxProgressWidth = bgParams?.width ?: 600
    progressBarFill?.layoutParams?.width = 0
    progressBarFill?.requestLayout()

    var currentProgress = 0
    val totalDuration = 2000L // Длительность загрузки (2 секунды)
    val interval = 50L        // Шаг обновления (50 мс)
    val totalSteps = totalDuration / interval

    // Запускаем игровой цикл обновления шкалы
    val progressRunnable = object : Runnable {
        var step = 0
        override fun run() {
            if (step >= totalSteps) {
                // Загрузка завершена -> Переходим к растворению экрана
                fadeOutLoadingAndStartGame()
                return
            }

            // 1. Рассчитываем заполнение зеленой шкалы
            step++
            val ratio = step.toFloat() / totalSteps.toFloat()
            progressBarFill?.layoutParams?.width = (maxProgressWidth * ratio).toInt()
            progressBarFill?.requestLayout()

            // 2. Имитация тряски шкалы (рандомное смещение по X и Y на пару пикселей)
            val shakeX = Random.nextInt(-6, 7).toFloat()
            val shakeY = Random.nextInt(-4, 5).toFloat()
            progressBarBg?.translationX = shakeX
            progressBarBg?.translationY = shakeY
            downloadText?.translationX = shakeX

            // 3. Мигание цвета шкалы с зеленого на красный (с шансом 25% на каждом шаге)
            if (Random.nextInt(0, 4) == 0) {
                progressBarFill?.setBackgroundColor(Color.RED)
            } else {
                progressBarFill?.setBackgroundColor(Color.GREEN)
            }

            handler.postDelayed(this, interval)
        }
    }
    handler.post(progressRunnable)
}

private fun fadeOutLoadingAndStartGame() {
    // Возвращаем шкалу в ровное положение
    progressBarBg?.translationX = 0f
    progressBarBg?.translationY = 0f
    downloadText?.translationX = 0f
    progressBarFill?.setBackgroundColor(Color.GREEN)

    // Запускаем плавное исчезновение (Fade Out) за 500 миллисекунд
    var alphaVal = 1.0f
    val fadeRunnable = object : Runnable {
        override fun run() {
            alphaVal -= 0.1f
            if (alphaVal <= 0f) {
                progressContainer?.visibility = View.GONE
                // Переходим к запуску таймера виджета и включаем шедевр ransom-theme.mp3
                startRansomWidgetGame()
                return
            }
            progressContainer?.alpha = alphaVal
            handler.postDelayed(this, 50L) // Шаг анимации исчезновения
        }
    }
    handler.post(fadeRunnable)
}

    private fun startRansomWidgetGame() {
        gameActive = true
        overlayRoot?.setOnTouchListener(null)
        
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        runCatching { windowManager.updateViewLayout(overlayRoot, layoutParams) }

        ransomWidget?.visibility = View.VISIBLE

        startThemeTrack(R.raw.ransom_theme)
        startRansomCountdown()
    }

        private fun startRansomCountdown() {
        var timeLeft = 90 // Ровно 1 минута 30 секунд, как и длительность OST
        countdownJob = serviceScope.launch(Dispatchers.Main) {
            while (timeLeft > 0 && gameActive) {
                // Математический перевод секунд в формат ММ:СС
                val minutes = timeLeft / 60
                val seconds = timeLeft % 60
                widgetTimerText?.text = String.format("%02d:%02d", minutes, seconds)
                
                if (gameScore >= 500) {
                    onRansomSuccessPaid()
                    return@launch
                }
                
                delay(1000L) // Тот самый delay внизу цикла
                timeLeft--
            }
            if (gameActive) {
                onRansomDefeatTimeout()
            }
        }
    }
	
             
	        private fun startThemeTrack(audioResId: Int) {
    try {
        themePlayer?.release()
        themePlayer = MediaPlayer.create(this, audioResId).apply {
            start() // Просто старт, без циклов!
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
private fun cancelGameJobs() {
        countdownJob?.cancel()
        coinMonitorJob?.cancel()
        teleportJob?.cancel()
    }
				}
                
                
.timeLeft--}if (gameActive) {onRansomDefeatTimeout()}}}private fun onRansomSuccessPaid() {stopThemeTrack()executeAudioTrack(R.raw.win)Toast.makeText(this, "Выкуп принят!", Toast.LENGTH_SHORT).show()resetToNormalState()}private fun onRansomDefeatTimeout() {stopThemeTrack()executeAudioTrack(R.raw.ransom_exe_jumpscare)blackScreenView?.visibility = View.VISIBLElayoutParams.flags = PANIC_FLAGSrunCatching { windowManager.updateViewLayout(overlayRoot, layoutParams) }serviceScope.launch { coinManager.cleanupCoins() }handler.postDelayed({blackScreenView?.visibility = View.GONEresetToNormalState()}, 3000L)}private fun resetToNormalState() {gameActive = falsecountdownJob?.cancel()ransomWidget?.visibility = View.GONEendPanicMode()}private fun endPanicMode() {isPanicMode = falsepanicView?.visibility = View.INVISIBLEoverlayRoot?.setOnTouchListener(null)layoutParams.flags = NORMAL_FLAGSrunCatching { windowManager.updateViewLayout(overlayRoot, layoutParams) }}private fun executeAudioTrack(audioResId: Int) {try {mediaPlayer?.stop()mediaPlayer?.release()mediaPlayer = MediaPlayer.create(this, audioResId).apply {start()setOnCompletionListener { releaseAudio() }}} catch (e: Exception) {e.printStackTrace()}}private fun startThemeTrack(audioResId: Int) {try {themePlayer?.release()themePlayer = MediaPlayer.create(this, audioResId).apply {isLooping = truestart()}} catch (e: Exception) {e.printStackTrace()}}private fun stopThemeTrack() {themePlayer?.stop()themePlayer?.release()themePlayer = null}private fun releaseAudio() {mediaPlayer?.release()mediaPlayer = null}private fun cancelGameJobs() {countdownJob?.cancel()coinMonitorJob?.cancel()teleportJob?.cancel()}private suspend fun cleanupPreviousSession() {}}